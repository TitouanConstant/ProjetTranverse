<template>
  <v-app>
    <v-main>
      <v-container class="fill-height" fluid>
        <v-row justify="center" align="center">
          <v-col cols="12" sm="8" md="6" class="text-center">
            <h1 class="display-2 text-white mb-3">Luxury Watches</h1>
            <p class="subtitle-1 text-white">
              Explore our exclusive collection of luxury watches, where elegance meets precision. Each timepiece is a testament to craftsmanship and timeless style.
            </p>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: 'HomePage'
}
</script>

<style scoped>

</style>
